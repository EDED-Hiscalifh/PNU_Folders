function pfeLaplace(num,den)

disp('>>>>> zeros <<<<<')
z = roots(num)
[r, p] = residue(num, den);
disp('>>>>> poles <<<<<')
p
disp('>>>>> Residues <<<<<<')
r
splane(num, den)