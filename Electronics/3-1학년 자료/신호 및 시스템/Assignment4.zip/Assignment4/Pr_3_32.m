%Problem 3.32
%(a)
clear all; clf
den=conv([1 0],[1 1]); den=conv(den,[1 10 50])
syms s t w
disp('>>>>> Inverse Laplace <<<<<')
x=ilaplace((s^2+2*s+1)/(den(1)*s^4+den(2)*s^3+den(3)*s^2+den(4)*s+den(5)))
figure(1)
ezplot(x,[0,5])
axis([0 5 0 .1])
grid
x = -1/50*exp(-5*t)*cos(5*t)+9/50*exp(-5*t)*sin(5*t)+1/50

%(b)
clear all; clf
syms s t w
x=ilaplace((1-s*exp(-s))/(s^2+2*s))
figure(2)
ezplot(x,[0,5])
axis([0 5 -0.6 0.6])
grid
x = exp(-t)*sinh(t)-heaviside(t-1)*exp(-2*t+2)