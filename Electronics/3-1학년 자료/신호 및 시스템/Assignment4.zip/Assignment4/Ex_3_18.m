clear all; clf
syms s t w
num=[0 3 2 -5]; den=[1 6 11 6];       
subplot(121)
splane(num,den)                 
disp('»Inverse Laplace«')
x=ilaplace((3*s^2+2*s+3)/(s^3+6*s^2+11*s+6));    
subplot(122)
ezplot(x,[0,12]); title('x(t)')
axis([0 12 -0.5 2.5]); grid