%Problem 3.38

clear all; clf
T=2;
num=[0 0 1/T]
den=[1 0 pi^2]
syms s t y
figure(1)
subplot(221)
pfeLaplace(num,den);
disp('>>>>> Inverse Laplace <<<<<')
y1=ilaplace(0.5/(s^2+pi^2))
subplot(222)
ezplot(y1,[0,8])
axis([0 8 -0.2 0.2]); title('y_1(t)')
grid
y=y1-y1*heaviside(t-2)
subplot(223)
ezplot(y,[0,8])
axis([0 8 -0.2 0.2]); title('y(t)')
grid