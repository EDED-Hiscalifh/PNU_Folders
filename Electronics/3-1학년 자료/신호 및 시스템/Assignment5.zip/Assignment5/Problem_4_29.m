% Problem 4_29
clear all; clf

X(1)=0.5;Y(1)=X(1);
for k=1:40,
X(k+1)=abs(0.5 *sin(pi*k/2)/(pi*k*0.5));
end
Y=X;
kk=-40:40;
X=[fliplr(X) X(2:41)];
Y=[fliplr(Y) Y(2:41)];
figure(1)
subplot(211)
stem(pi*kk,X); grid;axis([-40*pi 40*pi 0 0.6]);ylabel('|X_k|')
subplot(212)
stem(2*pi*kk,Y); grid;axis([-40*2*pi 40*2*pi 0 0.6]);ylabel('|Y_k|')