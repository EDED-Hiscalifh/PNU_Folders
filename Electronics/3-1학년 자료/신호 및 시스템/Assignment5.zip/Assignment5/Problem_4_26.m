% Problem 4_26
clear all; clf

X(1)=0.5;
for k=1:40,
X(k+1)=abs(0.5*sin(pi*k/2)/(pi*k/2));
end
kk=-40:40;
X=[fliplr(X) X(2:41)];
figure(1)
stem(kk,X); grid;axis([-40 40 0 0.6]);ylabel('|X_k|')

t=0:0.001:10;
x=0.5*ones(1,length(t));
for k=1:40,
x=x+(sin(pi*k/2)/(pi*k/2))*cos(pi*k*t-k*pi/2);
end
figure(2)
plot(t,x);grid
xlabel('t (sec)'); ylabel('x_a(t)')