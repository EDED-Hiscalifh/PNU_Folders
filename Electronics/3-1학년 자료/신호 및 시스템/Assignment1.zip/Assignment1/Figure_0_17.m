%%
% Creating a WAV file from scratch and reading it back
%A%
clear all
Fs = 5000;
t = 0:1/Fs: 5;
y = 0.1*cos(2*pi*2000*t)-0.8*cos(2*pi*2000*t.^2);
%% writing chirp.wav file
audiowrite('chirp.wav', y, Fs)
%% reading chirp.wav back into MATLAB as y1 and listening to it
[y1, Fs] = audioread('chirp.wav');
info = audioinfo('chirp.wav')
sound(y1, Fs)
plot(t(1:1000), y1(1:1000))
xlabel('Time')