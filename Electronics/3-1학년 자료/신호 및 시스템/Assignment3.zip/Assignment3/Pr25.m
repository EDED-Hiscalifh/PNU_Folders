% Problem 2.25

clear all; clf
Ts = 0.01; delay = 1; Tend = 20;
t = 0:Ts:Tend;

x = ramp(t,1,0)+ramp(t,-2,-2)+ramp(t,1,-8);
h = exp(-t);
y = Ts*conv(x,h);

t1 = 0:Ts:length(y)*Ts-Ts;
figure(1)
subplot(311)
plot(t,x); axis([0 20 -5 3]); grid; ylabel('x(t)');
subplot(312)
plot(t,h); axis([0 20 -0.1 1]); grid; ylabel('h(t)');
subplot(313)
plot(t1,y); grid;