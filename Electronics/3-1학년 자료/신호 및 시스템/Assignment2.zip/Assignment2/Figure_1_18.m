% Example 1.18

t = sym('t');
y = exp(-t)*cos(2*pi*t);
ye = exp(-t);
figure(1)

ezplot(y,[-2,4])
hold on
ezplot(ye,[-2,4])
hold on
ezplot(-ye,[-2,4]); axis([-2 4 -8 8])

figure(2)
t = sym('t')
x = 1+ 1.5*cos(2*pi*t/10)-.6*cos(4*pi*t/10);
ezplot(x,[-10,10]);grid
xlabel('t'); ylabel('x(t)')

