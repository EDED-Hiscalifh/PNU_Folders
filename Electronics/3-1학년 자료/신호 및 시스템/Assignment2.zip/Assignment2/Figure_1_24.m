% Example 1.24
clear all; clf

t = -5:0.01:5;
x = sin(5*pi*t);
y1 = ramp(t,2,2);
y2 = ramp(t,-4,0);
y3 = ramp(t,1,-2);
y4 = ramp(t,1,-3);
y5 = ustep(t,-3);
y = y1+y2+y3+y4+y5;


z = y.*x;
sound(100*z, 1000)
plot(t,z,'k'); hold on
plot(t,y,'r', t,-y, 'r'); axis([-5 5 -5 5]); grid
hold off
xlabel('t'); ylabel('z(t)')
figure(1)