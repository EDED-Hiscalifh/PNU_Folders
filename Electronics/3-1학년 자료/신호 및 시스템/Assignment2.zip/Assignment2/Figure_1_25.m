clear all; clf
syms x t
x = sin(pi*t); T=1;
figure(8)
ezplot(x^2, [0,5*T]);grid
P = int(x^2, t, 0, T)/T